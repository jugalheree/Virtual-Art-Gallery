import React, { useState } from 'react';

const CreateProfile = () => {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    bio: '',
    artistType: 'painter',
    website: '',
    instagram: '',
    password: '',
    confirmPassword: '',
    profileImage: null,
    coverImage: null,
    artworkImages: []
  });

  const [preview, setPreview] = useState({
    profile: null,
    cover: null,
    artworks: []
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
  };

  const handleImageChange = (e) => {
    const { name, files } = e.target;
    
    if (name === 'artworkImages') {
      // Handle multiple artwork images
      const newArtworks = [...formData.artworkImages];
      const newPreviews = [...preview.artworks];
      
      Array.from(files).forEach(file => {
        newArtworks.push(file);
        newPreviews.push(URL.createObjectURL(file));
      });
      
      setFormData({
        ...formData,
        artworkImages: newArtworks
      });
      
      setPreview({
        ...preview,
        artworks: newPreviews
      });
    } else {
      // Handle single image (profile or cover)
      if (files && files[0]) {
        setFormData({
          ...formData,
          [name]: files[0]
        });
        
        setPreview({
          ...preview,
          [name === 'profileImage' ? 'profile' : 'cover']: URL.createObjectURL(files[0])
        });
      }
    }
  };

  const removeArtwork = (index) => {
    const newArtworks = [...formData.artworkImages];
    const newPreviews = [...preview.artworks];
    
    newArtworks.splice(index, 1);
    newPreviews.splice(index, 1);
    
    setFormData({
      ...formData,
      artworkImages: newArtworks
    });
    
    setPreview({
      ...preview,
      artworks: newPreviews
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Here you would handle form submission, validation, etc.
    console.log('Form submitted:', formData);
    alert('Profile creation successful! Redirecting to your new profile...');
    // Redirect to artist profile page or show success message
  };

  return (
    <div className="create-profile-container">
      <div className="create-profile-content">
        <div className="profile-header">
          <h1>Create Artist Profile</h1>
          <p>Showcase your artwork and connect with art enthusiasts worldwide</p>
        </div>
        
        <form className="profile-form" onSubmit={handleSubmit}>
          <div className="form-section">
            <h2>Personal Information</h2>
            
            <div className="form-group">
              <div className="form-row">
                <div className="form-field">
                  <label htmlFor="firstName">First Name*</label>
                  <input 
                    type="text" 
                    id="firstName" 
                    name="firstName" 
                    value={formData.firstName} 
                    onChange={handleChange} 
                    required 
                  />
                </div>
                
                <div className="form-field">
                  <label htmlFor="lastName">Last Name*</label>
                  <input 
                    type="text" 
                    id="lastName" 
                    name="lastName" 
                    value={formData.lastName} 
                    onChange={handleChange} 
                    required 
                  />
                </div>
              </div>
              
              <div className="form-field">
                <label htmlFor="email">Email Address*</label>
                <input 
                  type="email" 
                  id="email" 
                  name="email" 
                  value={formData.email} 
                  onChange={handleChange} 
                  required 
                />
              </div>
              
              <div className="form-field">
                <label htmlFor="artistType">Artist Type*</label>
                <select 
                  id="artistType" 
                  name="artistType" 
                  value={formData.artistType} 
                  onChange={handleChange} 
                  required
                >
                  <option value="painter">Painter</option>
                  <option value="sculptor">Sculptor</option>
                  <option value="photographer">Photographer</option>
                  <option value="digital">Digital Artist</option>
                  <option value="mixed-media">Mixed Media</option>
                  <option value="other">Other</option>
                </select>
              </div>
              
              <div className="form-field">
                <label htmlFor="bio">Artist Bio*</label>
                <textarea 
                  id="bio" 
                  name="bio" 
                  value={formData.bio} 
                  onChange={handleChange} 
                  rows="4" 
                  required
                ></textarea>
                <p className="field-hint">Tell us about your artistic journey, influences, and style (150-300 words)</p>
              </div>
            </div>
          </div>
          
          <div className="form-section">
            <h2>Profile Images</h2>
            
            <div className="form-row image-upload-row">
              <div className="form-field image-upload">
                <label htmlFor="profileImage">Profile Image*</label>
                <div className="image-preview-container">
                  {preview.profile ? (
                    <img src={preview.profile} alt="Profile Preview" className="image-preview" />
                  ) : (
                    <div className="image-placeholder">
                      <i className="fas fa-user"></i>
                    </div>
                  )}
                  <input 
                    type="file" 
                    id="profileImage" 
                    name="profileImage" 
                    accept="image/*" 
                    onChange={handleImageChange} 
                    required={!formData.profileImage}
                  />
                  <label htmlFor="profileImage" className="upload-button">Choose Image</label>
                </div>
              </div>
              
              <div className="form-field image-upload">
                <label htmlFor="coverImage">Cover Image</label>
                <div className="image-preview-container cover-preview">
                  {preview.cover ? (
                    <img src={preview.cover} alt="Cover Preview" className="image-preview" />
                  ) : (
                    <div className="image-placeholder wide">
                      <i className="fas fa-image"></i>
                    </div>
                  )}
                  <input 
                    type="file" 
                    id="coverImage" 
                    name="coverImage" 
                    accept="image/*" 
                    onChange={handleImageChange} 
                  />
                  <label htmlFor="coverImage" className="upload-button">Choose Cover</label>
                </div>
              </div>
            </div>
          </div>
          
          <div className="form-section">
            <h2>Artwork Samples</h2>
            <p className="section-description">Upload 3-5 high-quality images of your best work</p>
            
            <div className="form-field artwork-upload">
              <input 
                type="file" 
                id="artworkImages" 
                name="artworkImages" 
                accept="image/*" 
                multiple 
                onChange={handleImageChange} 
              />
              <label htmlFor="artworkImages" className="upload-button artwork-upload-btn">
                <i className="fas fa-plus"></i> Add Artwork
              </label>
              
              <div className="artwork-previews">
                {preview.artworks.map((src, index) => (
                  <div key={index} className="artwork-preview-item">
                    <img src={src} alt={`Artwork ${index + 1}`} />
                    <button 
                      type="button" 
                      className="remove-artwork" 
                      onClick={() => removeArtwork(index)}
                    >
                      <i className="fas fa-times"></i>
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>
          
          <div className="form-section">
            <h2>Social & Web</h2>
            
            <div className="form-field">
              <label htmlFor="website">Personal Website</label>
              <input 
                type="url" 
                id="website" 
                name="website" 
                placeholder="https://www.yourwebsite.com" 
                value={formData.website} 
                onChange={handleChange} 
              />
            </div>
            
            <div className="form-field">
              <label htmlFor="instagram">Instagram</label>
              <div className="social-input">
                <span className="social-prefix">@</span>
                <input 
                  type="text" 
                  id="instagram" 
                  name="instagram" 
                  placeholder="your_instagram_handle" 
                  value={formData.instagram} 
                  onChange={handleChange} 
                />
              </div>
            </div>
          </div>
          
          <div className="form-section">
            <h2>Account Security</h2>
            
            <div className="form-field">
              <label htmlFor="password">Password*</label>
              <input 
                type="password" 
                id="password" 
                name="password" 
                value={formData.password} 
                onChange={handleChange} 
                required 
                minLength="8"
              />
              <p className="field-hint">Must be at least 8 characters long</p>
            </div>
            
            <div className="form-field">
              <label htmlFor="confirmPassword">Confirm Password*</label>
              <input 
                type="password" 
                id="confirmPassword" 
                name="confirmPassword" 
                value={formData.confirmPassword} 
                onChange={handleChange} 
                required 
              />
            </div>
          </div>
          
          <div className="form-actions">
            <button type="submit" className="btn btn-primary">Create Profile</button>
            <button type="button" className="btn btn-secondary">Cancel</button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default CreateProfile;