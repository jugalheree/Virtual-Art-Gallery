import React, { useEffect, useState } from "react";
import { BrowserRouter as Router, Routes, Route, Link, useNavigate } from "react-router-dom";
import "./App.css";
import CreateProfile from "./CreateProfile";
import Gallery from "./Gallery";

const Navbar = () => {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <header className={scrolled ? "scrolled" : ""}>
      <nav>
        <Link to="/" className="logo">Art Square Gallery</Link>
        <div className="nav-links">
          <a href="#features">Features</a>
          <a href="#exhibitions">Exhibitions</a>
          <a href="#artists">Artists</a>
          <a href="#contact">Contact</a>
          <Link to="/gallery">Gallery</Link>
        </div>
      </nav>
    </header>
  );
};

const Hero = () => {
  const navigate = useNavigate();
  
  return (
    <section className="hero">
      <div className="hero-content">
        <h1>Discover the Future of Art</h1>
        <p>Experience a curated collection of contemporary masterpieces from emerging artists worldwide.</p>
        <div className="cta-buttons">
          <Link to="/create-profile" className="btn btn-primary">Start Creating</Link>
          <button 
            className="btn btn-secondary" 
            onClick={() => navigate('/gallery')}
          >
            Explore Gallery
          </button>
        </div>
      </div>
    </section>
  );
};

const FeatureCard = ({ icon, title, description }) => (
  <div className="feature-card">
    <i className={`fas ${icon} feature-icon`}></i>
    <h3>{title}</h3>
    <p>{description}</p>
  </div>
);

const Features = () => (
  <section className="features" id="features">
    <h2 className="section-title">What We Offer</h2>
    <div className="feature-grid">
      <FeatureCard icon="fa-palette" title="Artist Profiles" description="Create your professional portfolio and connect with art enthusiasts worldwide." />
      <FeatureCard icon="fa-vr-cardboard" title="Virtual Exhibitions" description="Experience immersive art shows from the comfort of your home." />
      <FeatureCard icon="fa-lock" title="Secure Transactions" description="Buy and sell artwork with confidence using our secure payment system." />
    </div>
  </section>
);

const ExhibitionCard = ({ image, title, description }) => (
  <div className="exhibition-card">
    <img src={image} alt={title} />
    <h3>{title}</h3>
    <p>{description}</p>
  </div>
);

const Exhibitions = () => (
  <section className="exhibitions" id="exhibitions">
    <h2 className="section-title">Upcoming Exhibitions</h2>
    <div className="exhibition-grid">
      <ExhibitionCard image="https://images.unsplash.com/photo-1594794312433-05a69a98b7a0?q=80&w=2070&auto=format&fit=crop" title="Contemporary Art Exhibition" description="Experience our latest collection of contemporary artworks." />
    </div>
  </section>
);

const ArtistCard = ({ image, name, bio }) => (
  <div className="artist-card">
    <img src={image} alt={name} />
    <h3>{name}</h3>
    <p>{bio}</p>
  </div>
);

const Artists = () => (
  <section className="artists" id="artists">
    <h2 className="section-title">Featured Artists</h2>
    <div className="artist-grid">
      <ArtistCard image="https://upload.wikimedia.org/wikipedia/commons/6/6d/Ravivarma1b.jpg" name="Raja Ravi Varma" bio="Raja Ravi Varma was an Indian painter and artist. His works are one of the best examples of the fusion of European academic art with a purely Indian sensibility and iconography." />
    </div>
    <div className="artist-grid">
      <ArtistCard image="https://laasyaart.com/wp-content/uploads/2024/04/Amit-Bhar-Artist.jpg" name="Amit Bhar" bio="Contemporary artist Amit Bhar melds realism and mysticism in his paintings, evoking a trance-like sense of calm and contemplation" />
    </div>
    <div className="artist-grid">
      <ArtistCard image="https://laasyaart.com/wp-content/uploads/2019/08/ANURADHA_THAKUR-212x300.jpg" name="Anuradha Thakur" bio="Raja Ravi Varma was an Indian painter and artist. His works are one of the best examples of the fusion of European academic art with a purely Indian sensibility and iconography." />
    </div>
  </section>
);

const Contact = () => {
  const handleSubmit = async (event) => {
    event.preventDefault();
    const formData = new FormData(event.target);
    const data = Object.fromEntries(formData.entries());

    try {
      const response = await fetch("http://localhost:3000/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      alert(response.ok ? "Message sent successfully!" : "Failed to send message.");
    } catch (error) {
      alert("An error occurred while sending the message.");
    }
  };

  return (
    <section className="contact" id="contact">
      <h2 className="section-title">Contact Us</h2>
      <div className="contact-form">
        <form onSubmit={handleSubmit}>
          <input type="text" name="name" placeholder="Name" required />
          <input type="email" name="email" placeholder="Email" required />
          <textarea name="message" placeholder="Message" required></textarea>
          <button type="submit" className="btn btn-primary">Send Message</button>
        </form>
      </div>
    </section>
  );
};

const Footer = () => (
  <footer>
    <p>&copy; 2025 Art Square Gallery. All rights reserved.</p>
  </footer>
);

const HomePage = () => (
  <>
    <Hero />
    <Features />
    <Exhibitions />
    <Artists />
    <Contact />
  </>
);

const App = () => (
  <Router>
    <Navbar />
    <Routes>
      <Route path="/" element={<HomePage />} />
      <Route path="/create-profile" element={<CreateProfile />} />
      <Route path="/gallery" element={<Gallery />} />
    </Routes>
    <Footer />
  </Router>
);

export default App;