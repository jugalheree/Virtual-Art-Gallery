import React, { useState } from 'react';

const Gallery = () => {
  const [filter, setFilter] = useState('all');
  
  // Sample artwork data
  const artworks = [
    {
      id: 1,
      title: "Shakuntala",
      artist: "Raja Ravi Varma",
      image: "https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Raja_Ravi_Varma_-_Mahabharata_-_Shakuntala.jpg/800px-Raja_Ravi_Varma_-_Mahabharata_-_Shakuntala.jpg",
      category: "painting",
      price: "$2,400"
    },
    {
      id: 2,
      title: "Urban Landscape",
      artist: "Amit Bhar",
      image: "https://images.unsplash.com/photo-1579783902614-a3fb3927b6a5?q=80&w=1000&auto=format&fit=crop",
      category: "photography",
      price: "$1,800"
    },
    {
      id: 3,
      title: "Serenity",
      artist: "Anuradha Thakur",
      image: "https://images.unsplash.com/photo-1559102877-4a2cc0e37fce?q=80&w=1000&auto=format&fit=crop",
      category: "sculpture",
      price: "$3,200"
    },
    {
      id: 4,
      title: "Vibrant Dreams",
      artist: "Raja Ravi Varma",
      image: "https://images.unsplash.com/photo-1561214115-f2f134cc4912?q=80&w=1000&auto=format&fit=crop",
      category: "painting",
      price: "$2,100"
    },
    {
      id: 5,
      title: "Banaras Ghat 10",
      artist: "Amit Bhar",
      image: "https://www.eikowa.com/cdn/shop/files/WhatsAppImage2024-08-08at5.20.42PM.jpg?v=1723182383&width=533",
      category: "painting",
      price: "$1,500"
    },
    {
      id: 6,
      title: "Rythm of Season",
      artist: "Anuradha Thakur",
      image: "https://laasyaart.com/wp-content/uploads/2021/06/Rhythm-of-season-27-60x48-web.jpg",
      category: "photography",
      price: "$7,500"
    },
    {
      id: 7,
      title: "Modern Perspectives",
      artist: "Raja Ravi Varma",
      image: "https://images.unsplash.com/photo-1549490349-8643362247b5?q=80&w=1000&auto=format&fit=crop",
      category: "painting",
      price: "$2,700"
    },
    {
      id: 8,
      title: "Digital Dreams",
      artist: "Amit Bhar",
      image: "https://images.unsplash.com/photo-1618005198919-d3d4b5a92ead?q=80&w=1000&auto=format&fit=crop",
      category: "digital",
      price: "$1,650"
    },
    {
      id: 9,
      title: "Celebration With Friends",
      artist: "Anuradha Thakur",
      image: "https://laasyaart.com/wp-content/uploads/2023/09/Celebration-AT35@new-808x1024.jpg",
      category: "sculpture",
      price: "$3,800"
    }
  ];

  const filteredArtworks = filter === 'all' 
    ? artworks 
    : artworks.filter(artwork => artwork.category === filter);

  return (
    <div className="gallery-container">
      <div className="gallery-content">
        <div className="gallery-header">
          <h1>Art Gallery</h1>
          <p>Explore our curated collection of exceptional artworks from talented artists around the world.</p>
        </div>
        
        <div className="gallery-filters">
          <button 
            className={`filter-btn ${filter === 'all' ? 'active' : ''}`} 
            onClick={() => setFilter('all')}
          >
            All Artworks
          </button>
          <button 
            className={`filter-btn ${filter === 'painting' ? 'active' : ''}`} 
            onClick={() => setFilter('painting')}
          >
            Paintings
          </button>
          <button 
            className={`filter-btn ${filter === 'sculpture' ? 'active' : ''}`} 
            onClick={() => setFilter('sculpture')}
          >
            Sculptures
          </button>
          <button 
            className={`filter-btn ${filter === 'photography' ? 'active' : ''}`} 
            onClick={() => setFilter('photography')}
          >
            Photography
          </button>
          <button 
            className={`filter-btn ${filter === 'digital' ? 'active' : ''}`} 
            onClick={() => setFilter('digital')}
          >
            Digital Art
          </button>
        </div>
        
        <div className="gallery-grid">
          {filteredArtworks.map(artwork => (
            <div key={artwork.id} className="artwork-card">
              <div className="artwork-image">
                <img src={artwork.image} alt={artwork.title} />
              </div>
              <div className="artwork-info">
                <h3>{artwork.title}</h3>
                <p className="artist-name">by {artwork.artist}</p>
                <p className="artwork-price">{artwork.price}</p>
                <button className="btn btn-primary">View Details</button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Gallery;